# praktikum 4.2

A Pen created on CodePen.

Original URL: [https://codepen.io/Nailarizqya/pen/RNrxKxV](https://codepen.io/Nailarizqya/pen/RNrxKxV).

